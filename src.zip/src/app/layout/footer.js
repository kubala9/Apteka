export const footer = {
  template: require('./footer.html')
};
