export const menu = {
  template: require('./menu.html')
};
