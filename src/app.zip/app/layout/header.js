export const header = {
  template: require('./header.html')
};
